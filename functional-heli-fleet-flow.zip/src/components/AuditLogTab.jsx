import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { SelectItem } from "@/components/ui/select";
import { ResponsiveSelect } from "@/components/ui/responsive-select";
import { format } from "date-fns";
import { Plane, Droplet, Wrench, Pencil, Plus, History } from "lucide-react";

const TYPE_META = {
  flight: { label: "Flight", icon: Plane, color: "text-blue-600", bg: "bg-blue-100 dark:bg-blue-950" },
  fuel: { label: "Fuel", icon: Droplet, color: "text-emerald-600", bg: "bg-emerald-100 dark:bg-emerald-950" },
  inspection: { label: "Inspection", icon: Wrench, color: "text-amber-600", bg: "bg-amber-100 dark:bg-amber-950" },
  edit: { label: "Edit", icon: Pencil, color: "text-slate-600", bg: "bg-slate-100 dark:bg-slate-800" },
  create: { label: "Created", icon: Plus, color: "text-violet-600", bg: "bg-violet-100 dark:bg-violet-950" },
};

export default function AuditLogTab({ aircraft }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.FlightLog.list("-created_date", 200);
      setLogs(list);
    } catch {
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = filter === "all" ? logs : logs.filter((l) => l.aircraft_id === filter);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-muted-foreground" />
          <h3 className="font-semibold">Audit Trail</h3>
          <span className="text-sm text-muted-foreground">({logs.length} entries)</span>
        </div>
        <div className="w-56">
          <ResponsiveSelect value={filter} onValueChange={setFilter} placeholder="All aircraft">
            <SelectItem value="all">All aircraft</SelectItem>
            {aircraft.map((a) => (
              <SelectItem key={a.id} value={a.id}>{a.tail_number}</SelectItem>
            ))}
          </ResponsiveSelect>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-border rounded-2xl">
          <History className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
          <p className="text-muted-foreground">No log entries yet.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Date</th>
                  <th className="text-left font-medium px-4 py-3">Pilot</th>
                  <th className="text-left font-medium px-4 py-3">Aircraft</th>
                  <th className="text-left font-medium px-4 py-3">Type</th>
                  <th className="text-right font-medium px-4 py-3">Hours</th>
                  <th className="text-right font-medium px-4 py-3">Fuel (gal)</th>
                  <th className="text-left font-medium px-4 py-3">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((l) => {
                  const meta = TYPE_META[l.entry_type] || TYPE_META.flight;
                  const Icon = meta.icon;
                  return (
                    <tr key={l.id} className="hover:bg-muted/30">
                      <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{l.created_date ? format(new Date(l.created_date), "MMM d, yyyy HH:mm") : "—"}</td>
                      <td className="px-4 py-3 font-medium">{l.pilot_name || "—"}</td>
                      <td className="px-4 py-3">{l.aircraft_tail || "—"}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${meta.bg} ${meta.color}`}>
                          <Icon className="w-3 h-3" />{meta.label}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">{Number(l.hours_added) ? `+${Number(l.hours_added).toFixed(1)}` : "—"}</td>
                      <td className="px-4 py-3 text-right">{Number(l.fuel_change) ? `${Number(l.fuel_change) > 0 ? "+" : ""}${Number(l.fuel_change).toFixed(1)}` : "—"}</td>
                      <td className="px-4 py-3 text-muted-foreground max-w-xs truncate">{l.notes || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}