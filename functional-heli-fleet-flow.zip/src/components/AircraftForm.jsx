import React, { useState, useEffect } from "react";
import { MotionSheet } from "@/components/ui/motion-sheet";
import { DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SelectItem } from "@/components/ui/select";
import { ResponsiveSelect } from "@/components/ui/responsive-select";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Upload, FileText, X } from "lucide-react";
import { safeHref } from "@/lib/safeUrl";

const EMPTY = {
  tail_number: "",
  model: "",
  status: "hangar",
  engine_hours: 0,
  blade_inspection_interval: 8,
  blade_inspection_last_hours: 0,
  hundred_hour_interval: 100,
  hundred_hour_last_hours: 0,
  annual_maintenance_last: "",
  annual_interval_months: 12,
  poh_file_url: "",
  notes: "",
};

export default function AircraftForm({ open, onClose, onSave, aircraft }) {
  const { toast } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [uploadingPoh, setUploadingPoh] = useState(false);

  useEffect(() => {
    if (open) setForm(aircraft ? { ...EMPTY, ...aircraft } : EMPTY);
  }, [open, aircraft]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handlePohUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPoh(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      set("poh_file_url", file_url);
      toast({ title: "POH uploaded" });
    } catch {
      toast({ title: "POH upload failed", variant: "destructive" });
    } finally {
      setUploadingPoh(false);
      e.target.value = "";
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave({
        ...form,
        engine_hours: Number(form.engine_hours) || 0,
        blade_inspection_interval: Number(form.blade_inspection_interval) || 0,
        blade_inspection_last_hours: Number(form.blade_inspection_last_hours) || 0,
        hundred_hour_interval: Number(form.hundred_hour_interval) || 0,
        hundred_hour_last_hours: Number(form.hundred_hour_last_hours) || 0,
        annual_interval_months: Number(form.annual_interval_months) || 12,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <MotionSheet open={open} onOpenChange={(o) => !o && onClose()} className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{aircraft ? "Edit Aircraft" : "Add Aircraft"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="tn">Tail Number *</Label>
              <Input id="tn" value={form.tail_number} onChange={(e) => set("tail_number", e.target.value)} required placeholder="N12345" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="md">Model</Label>
              <Input id="md" value={form.model} onChange={(e) => set("model", e.target.value)} placeholder="Bell 206" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Status</Label>
              <ResponsiveSelect value={form.status} onValueChange={(v) => set("status", v)} placeholder="Status">
                <SelectItem value="hangar">In Hangar</SelectItem>
                <SelectItem value="maintenance">In Maintenance</SelectItem>
              </ResponsiveSelect>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="eh">Engine Hours</Label>
              <Input id="eh" type="number" step="0.1" value={form.engine_hours} onChange={(e) => set("engine_hours", e.target.value)} />
            </div>
          </div>

          <div className="rounded-lg border border-border p-4 space-y-3 bg-muted/30">
            <p className="text-sm font-semibold">Pilot's Operating Handbook (POH)</p>
            {form.poh_file_url ? (
              <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-card px-3 py-2">
                <a href={safeHref(form.poh_file_url)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm text-primary hover:underline min-w-0">
                  <FileText className="w-4 h-4 shrink-0" />
                  <span className="truncate">View uploaded POH</span>
                </a>
                <Button type="button" size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => set("poh_file_url", "")}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 rounded-md border border-dashed border-border px-3 py-4 cursor-pointer hover:bg-muted/50 text-sm text-muted-foreground">
                <Upload className="w-4 h-4" />
                {uploadingPoh ? "Uploading…" : "Upload POH (PDF)"}
                <input type="file" accept="application/pdf" className="hidden" onChange={handlePohUpload} disabled={uploadingPoh} />
              </label>
            )}
          </div>

          <div className="rounded-lg border border-border p-4 space-y-3 bg-muted/30">
            <p className="text-sm font-semibold">Blade Inspection</p>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="bi">Interval (hrs)</Label>
                <Input id="bi" type="number" value={form.blade_inspection_interval} onChange={(e) => set("blade_inspection_interval", e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bl">Last done at (hrs)</Label>
                <Input id="bl" type="number" value={form.blade_inspection_last_hours} onChange={(e) => set("blade_inspection_last_hours", e.target.value)} />
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-border p-4 space-y-3 bg-muted/30">
            <p className="text-sm font-semibold">100-Hour Inspection</p>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="hi">Interval (hrs)</Label>
                <Input id="hi" type="number" value={form.hundred_hour_interval} onChange={(e) => set("hundred_hour_interval", e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="hl">Last done at (hrs)</Label>
                <Input id="hl" type="number" value={form.hundred_hour_last_hours} onChange={(e) => set("hundred_hour_last_hours", e.target.value)} />
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-border p-4 space-y-3 bg-muted/30">
            <p className="text-sm font-semibold">Annual Maintenance</p>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="ad">Last done on</Label>
                <Input id="ad" type="date" value={form.annual_maintenance_last || ""} onChange={(e) => set("annual_maintenance_last", e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ai">Interval (months)</Label>
                <Input id="ai" type="number" value={form.annual_interval_months} onChange={(e) => set("annual_interval_months", e.target.value)} />
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="nt">Notes</Label>
            <Textarea id="nt" value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={2} />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save Aircraft"}</Button>
          </DialogFooter>
        </form>
    </MotionSheet>
  );
}