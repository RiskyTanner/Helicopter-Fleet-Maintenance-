import React, { useState, useEffect } from "react";
import { MotionSheet } from "@/components/ui/motion-sheet";
import { DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Droplet } from "lucide-react";

// Quick dialog to add flight hours to the engine and optionally log fuel burned
// from the site inventory. The mission type is recorded so the Missions tab can
// auto-fill from logged flight time.
export default function LogHoursDialog({ open, onClose, onApply, aircraft, siteFuel }) {
  const [hours, setHours] = useState("");
  const [fuelBurn, setFuelBurn] = useState("");
  const [missionType, setMissionType] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) { setHours(""); setFuelBurn(""); setMissionType(""); setError(""); }
  }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    const h = Number(hours) || 0;
    const f = (Number(fuelBurn) || 0) * -1; // burn reduces site fuel
    if (!h && !fuelBurn) return;
    if (h > 0 && !missionType) { setError("Select a mission type"); return; }
    await onApply({ hoursAdded: h, fuelChange: f, missionType });
    onClose();
  };

  return (
    <MotionSheet open={open} onOpenChange={(o) => !o && onClose()} className="max-w-md">
        <DialogHeader>
          <DialogTitle>Log Time — {aircraft?.tail_number}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Current engine hours: <span className="font-semibold text-foreground">{Number(aircraft?.engine_hours || 0).toFixed(1)}</span>
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="lh">Hours to add</Label>
            <Input id="lh" type="number" step="0.1" min="0" value={hours} onChange={(e) => setHours(e.target.value)} placeholder="0.0" autoFocus />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="mt">Mission type</Label>
            <Input id="mt" value={missionType} onChange={(e) => { setMissionType(e.target.value); setError(""); }} placeholder="e.g. Training, Patrol, Touch-a-Truck" />
            {error && <p className="text-xs text-destructive">{error}</p>}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lf">Fuel burned this flight (gallons)</Label>
            <Input id="lf" type="number" step="0.1" min="0" value={fuelBurn} onChange={(e) => setFuelBurn(e.target.value)} placeholder="0" />
          </div>
          <div className="flex items-center gap-2 rounded-md bg-muted/40 px-3 py-2 text-sm">
            <Droplet className="w-4 h-4 text-emerald-600" />
            <span className="text-muted-foreground">Site fuel: <span className="font-semibold text-foreground">{Number(siteFuel?.total_fuel_on_site || 0).toFixed(1)} gal</span></span>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">Apply</Button>
          </DialogFooter>
        </form>
    </MotionSheet>
  );
}