import * as React from "react";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Drawer, DrawerTrigger, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { useIsMobile } from "@/hooks/use-mobile";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

// Select that renders as a Radix popover on desktop and a vaul slide-up
// bottom drawer (native iOS/Android action-sheet) on small viewports.
// Drop-in for the shadcn Select API: value, onValueChange, placeholder,
// and SelectItem children.
export function ResponsiveSelect({ value, onValueChange, placeholder, children, className }) {
  const isMobile = useIsMobile();
  const [open, setOpen] = React.useState(false);
  const options = React.Children.toArray(children).filter(Boolean);
  const selected = options.find((o) => o.props.value === value) || null;
  const label = selected ? selected.props.children : placeholder;

  if (!isMobile) {
    return (
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger className={className}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>{children}</SelectContent>
      </Select>
    );
  }

  return (
    <Drawer open={open} onOpenChange={setOpen} shouldScaleBackground={false}>
      <DrawerTrigger asChild>
        <button
          type="button"
          className={cn(
            "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
            className
          )}
        >
          <span className={cn("truncate", !selected && "text-muted-foreground")}>{label || placeholder}</span>
          <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
        </button>
      </DrawerTrigger>
      <DrawerContent className="max-h-[70vh]">
        <DrawerHeader className="pb-2">
          <DrawerTitle>{placeholder || "Select an option"}</DrawerTitle>
          <DrawerDescription className="sr-only">Choose an option</DrawerDescription>
        </DrawerHeader>
        <div className="overflow-y-auto px-2 pb-4">
          {options.map((o) => (
            <button
              key={o.props.value}
              type="button"
              onClick={() => {
                onValueChange?.(o.props.value);
                setOpen(false);
              }}
              className="flex w-full items-center justify-between rounded-md px-3 py-3 text-left text-base hover:bg-accent focus:bg-accent"
            >
              <span>{o.props.children}</span>
              {o.props.value === value && <Check className="h-4 w-4 text-primary shrink-0" />}
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

export default ResponsiveSelect;