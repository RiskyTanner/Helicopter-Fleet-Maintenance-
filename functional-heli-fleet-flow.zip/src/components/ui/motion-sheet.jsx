import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

// A Radix-backed sheet with a Framer Motion slide-up entrance/exit.
// Renders as a bottom sheet on mobile and a centered modal on >= sm,
// keeping Radix's focus trap, Escape handling, and accessibility.
export function MotionSheet({ open, onOpenChange, children, className }) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <AnimatePresence>
        {open && (
          <DialogPrimitive.Portal forceMount>
            <DialogPrimitive.Overlay asChild forceMount>
              <motion.div
                className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              />
            </DialogPrimitive.Overlay>
            <DialogPrimitive.Content asChild forceMount>
              <motion.div
                className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onPointerDown={(e) => {
                  if (e.target === e.currentTarget) onOpenChange?.(false);
                }}
              >
                <motion.div
                  onPointerDown={(e) => e.stopPropagation()}
                  className={cn(
                    "relative w-full bg-card text-card-foreground border border-border shadow-2xl rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col pb-safe",
                    className
                  )}
                  initial={{ y: "100%" }}
                  animate={{ y: 0 }}
                  exit={{ y: "100%" }}
                  transition={{ type: "spring", damping: 34, stiffness: 320 }}
                >
                  <DialogPrimitive.Close className="absolute right-3 top-3 z-10 rounded-sm p-1.5 text-muted-foreground hover:text-foreground opacity-70 hover:opacity-100 transition-opacity">
                    <X className="h-4 w-4" />
                    <span className="sr-only">Close</span>
                  </DialogPrimitive.Close>
                  <div className="flex-1 min-h-0 overflow-y-auto p-6">{children}</div>
                </motion.div>
              </motion.div>
            </DialogPrimitive.Content>
          </DialogPrimitive.Portal>
        )}
      </AnimatePresence>
    </DialogPrimitive.Root>
  );
}