import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// Suggests a readable name from an email's local part:
// "john.doe@gmail.com" -> "John Doe", "j-doe" -> "J Doe"
function suggestNameFromEmail(email) {
  if (!email) return "";
  const local = email.split("@")[0];
  return local
    .split(/[._+-]+/)
    .filter(Boolean)
    .map((p) => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase())
    .join(" ");
}

// Shown on first sign-in when the user has no display name. Prefills a name
// guessed from the email and saves it to the user profile so the logbook and
// audit trail show a real name instead of an email address.
export default function DisplayNameDialog({ open, user, onSaved }) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open && user) setName(suggestNameFromEmail(user.email));
  }, [open, user]);

  const save = async () => {
    const trimmed = name.trim();
    if (!trimmed || saving) return;
    setSaving(true);
    try {
      await base44.auth.updateMe({ display_name: trimmed });
      toast({ title: `Welcome, ${trimmed}` });
      onSaved?.(trimmed);
    } catch {
      toast({ title: "Could not save name", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => { /* non-dismissable until saved */ }}>
      <DialogContent
        className="sm:max-w-md"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <div className="mx-auto mb-2 h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="w-6 h-6 text-primary" />
          </div>
          <DialogTitle>Set your display name</DialogTitle>
          <DialogDescription>
            This is the name shown in the logbook and audit trail instead of your email address.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2 py-2">
          <Label htmlFor="display-name">Display name</Label>
          <Input
            id="display-name"
            value={name}
            autoFocus
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
            placeholder="e.g. Capt. John Doe"
          />
        </div>
        <DialogFooter>
          <Button onClick={save} disabled={!name.trim() || saving}>
            {saving ? "Saving…" : "Save name"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}