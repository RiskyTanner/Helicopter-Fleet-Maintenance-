import React, { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Trash2, Loader2 } from "lucide-react";

// Settings dialog with an account-data deletion flow. Deletion removes the
// aircraft and audit-log entries the current user created, then signs them
// out. A two-step confirmation guards against accidental deletion.
export default function SettingsDialog({ open, onClose }) {
  const { toast } = useToast();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const deleteAccount = async () => {
    setDeleting(true);
    try {
      const me = await base44.auth.me();
      const uid = me?.id;
      if (uid) {
        await base44.entities.FlightLog.deleteMany({ created_by_id: uid });
        await base44.entities.PilotLog.deleteMany({ created_by_id: uid });
        await base44.entities.Aircraft.deleteMany({ created_by_id: uid });
        // Permanently erase the authenticating profile (App Store 5.1.1(v)).
        // base44.auth exposes no deleteMe; removing the User record deletes the
        // app account and core profile.
        await base44.entities.User.delete(uid);
      }
      toast({ title: "Your account and records have been deleted" });
      setConfirmOpen(false);
    } catch {
      toast({ title: "Deletion failed", variant: "destructive" });
      setDeleting(false);
      return;
    }
    try { await base44.auth.logout("/login"); } catch { window.location.href = "/login"; }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-4">
              <h3 className="font-semibold text-destructive">Delete account</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Permanently deletes your account along with all aircraft, logbook, and audit entries you created, then signs you out. This cannot be undone.
              </p>
              <Button variant="destructive" className="mt-3 w-full" onClick={() => setConfirmOpen(true)}>
                <Trash2 className="w-4 h-4 mr-1.5" /> Delete my account
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmOpen} onOpenChange={(o) => { if (!deleting) setConfirmOpen(o); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete your account?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently deletes your account along with every aircraft, logbook, and audit-log entry you created, then signs you out. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); deleteAccount(); }}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Deleting…</> : "Yes, delete my account"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}