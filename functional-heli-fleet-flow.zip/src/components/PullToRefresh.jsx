import React, { useRef, useState } from "react";
import { RefreshCw } from "lucide-react";

// Touch-based pull-to-refresh. Only activates when the page is scrolled to
// the top, so normal scrolling is unaffected. Desktop (no touch) is a no-op.
export default function PullToRefresh({ onRefresh, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(0);
  const pulling = useRef(false);

  const THRESHOLD = 70;
  const MAX = 100;

  const onTouchStart = (e) => {
    if (window.scrollY > 0) return;
    startY.current = e.touches[0].clientY;
    pulling.current = true;
  };

  const onTouchMove = (e) => {
    if (!pulling.current || refreshing) return;
    const delta = e.touches[0].clientY - startY.current;
    if (delta > 0 && window.scrollY <= 0) {
      setPull(Math.min(delta * 0.5, MAX));
    }
  };

  const onTouchEnd = async () => {
    if (!pulling.current) return;
    pulling.current = false;
    if (pull >= THRESHOLD) {
      setRefreshing(true);
      setPull(THRESHOLD);
      try {
        await onRefresh();
      } finally {
        setRefreshing(false);
      }
    }
    setPull(0);
  };

  const height = refreshing ? THRESHOLD : pull;
  const rotate = Math.min(pull / THRESHOLD, 1) * 360;

  return (
    <div onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      <div
        className="flex items-center justify-center overflow-hidden"
        style={{ height, opacity: pull / THRESHOLD || (refreshing ? 1 : 0) }}
      >
        <RefreshCw
          className={`w-5 h-5 text-muted-foreground ${refreshing ? "animate-spin" : ""}`}
          style={{ transform: `rotate(${rotate}deg)` }}
        />
      </div>
      {children}
    </div>
  );
}