import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Thermometer, Gauge, Wind, RefreshCw, MapPin, CloudOff, Mountain } from "lucide-react";

// Live weather for Nashville International (KBNA) pulled via the
// getAirportWeather backend function. Shows temperature, barometric
// pressure, and wind; auto-refreshes every 10 minutes.
export default function WeatherWidget() {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("getAirportWeather", {});
      if (res.status >= 400) setError(res.data?.error || "Weather unavailable");
      else setWeather(res.data);
    } catch {
      setError("Weather unavailable");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 10 * 60 * 1000);
    return () => clearInterval(id);
  }, []);

  const obs = weather?.observation_time
    ? new Date(weather.observation_time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : null;

  return (
    <div className="rounded-xl border border-border bg-card p-4 select-none">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
          <div className="min-w-0">
            <p className="text-sm font-semibold leading-tight truncate">Nashville Intl (KBNA)</p>
            <p className="text-[11px] text-muted-foreground leading-tight">Airport Weather</p>
          </div>
        </div>
        <button
          type="button"
          onClick={load}
          className="h-8 w-8 inline-flex items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {error ? (
        <div className="flex flex-col items-center justify-center py-6 text-muted-foreground">
          <CloudOff className="w-6 h-6 mb-2" />
          <p className="text-xs">{error}</p>
        </div>
      ) : loading && !weather ? (
        <div className="flex justify-center py-6">
          <div className="w-6 h-6 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin dark:border-slate-700 dark:border-t-slate-200" />
        </div>
      ) : weather ? (
        <div className="space-y-3">
          {weather.summary && (
            <p className="text-sm text-muted-foreground capitalize">{weather.summary}</p>
          )}
          <div className="grid grid-cols-1 gap-2">
            <Row icon={<Thermometer className="w-4 h-4 text-orange-500" />} label="Temperature">
              {weather.temperature_f != null ? `${weather.temperature_f}°F` : "—"}
              {weather.temperature_c != null && (
                <span className="text-muted-foreground ml-1">({weather.temperature_c}°C)</span>
              )}
            </Row>
            <Row icon={<Gauge className="w-4 h-4 text-blue-500" />} label="Barometric">
              {weather.pressure_inhg != null ? `${weather.pressure_inhg} inHg` : "—"}
              {weather.pressure_mb != null && (
                <span className="text-muted-foreground ml-1">({weather.pressure_mb} mb)</span>
              )}
            </Row>
            <Row icon={<Mountain className="w-4 h-4 text-amber-600" />} label="Density Alt">
              {weather.density_altitude_ft != null ? `${weather.density_altitude_ft.toLocaleString()} ft` : "—"}
            </Row>
            <Row icon={<Wind className="w-4 h-4 text-teal-500" />} label="Wind">
              {weather.wind_metar ? (
                <span className="font-mono tracking-tight">{weather.wind_metar}</span>
              ) : (
                "—"
              )}
              {weather.wind_direction_cardinal && weather.wind_mph != null && (
                <span className="text-muted-foreground ml-1.5 text-xs">
                  {weather.wind_direction_cardinal} · {weather.wind_mph} mph
                </span>
              )}
            </Row>
          </div>
          {obs && <p className="text-[11px] text-muted-foreground pt-1 border-t border-border">Observed {obs}</p>}
        </div>
      ) : null}
    </div>
  );
}

function Row({ icon, label, children }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-lg bg-muted/40 px-3 py-2">
      <span className="flex items-center gap-2 text-xs text-muted-foreground">
        {icon}
        {label}
      </span>
      <span className="text-sm font-medium text-right">{children}</span>
    </div>
  );
}