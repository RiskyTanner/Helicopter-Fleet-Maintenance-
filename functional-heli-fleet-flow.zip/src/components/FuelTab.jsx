import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Droplet, Plus, Minus } from "lucide-react";
import { recordLogEntry } from "@/lib/logEntry";
import { useToast } from "@/components/ui/use-toast";

// Site-level fuel inventory: shows a single total and an adjustment form.
export default function FuelTab({ siteFuel, onReload }) {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [saving, setSaving] = useState(false);

  const total = Number(siteFuel?.total_fuel_on_site || 0);

  const submit = async (e) => {
    e.preventDefault();
    const delta = Number(amount) || 0;
    if (!delta) return;
    setSaving(true);
    try {
      const newTotal = Math.max(0, total + delta);
      await base44.entities.SiteFuel.update(siteFuel.id, { total_fuel_on_site: newTotal });
      await recordLogEntry({
        aircraft: { id: "", tail_number: "Site Fuel" },
        fuelChange: delta,
        entryType: "fuel",
        notes: delta > 0 ? "Fuel delivery added to site" : "Fuel burn logged from site",
      });
      toast({ title: "Fuel updated" });
      setAmount("");
      onReload();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="rounded-2xl border border-border bg-gradient-to-br from-emerald-50 to-card p-8 dark:from-emerald-950/40 dark:to-card">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-emerald-500 text-white flex items-center justify-center">
            <Droplet className="w-7 h-7" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Total Fuel On Site</p>
            <p className="text-4xl font-semibold">{total.toFixed(1)} <span className="text-xl text-muted-foreground">gal</span></p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="font-semibold mb-4">Adjust Fuel Inventory</h3>
        <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
          <div className="space-y-1.5">
            <Label htmlFor="amt">Gallons (positive to add delivery, negative to log burn)</Label>
            <Input id="amt" type="number" step="0.1" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.0" />
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setAmount(String(Math.abs(Number(amount) || 0)))}>
              <Plus className="w-4 h-4 mr-1" /> Add
            </Button>
            <Button type="submit" disabled={saving} className="flex-1">
              <Minus className="w-4 h-4 mr-1" /> Save
            </Button>
          </div>
        </form>
        <p className="text-xs text-muted-foreground mt-3">Every adjustment is recorded in the Audit Log with the pilot's name.</p>
      </div>
    </div>
  );
}