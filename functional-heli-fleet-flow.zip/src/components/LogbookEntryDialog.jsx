import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SelectItem } from "@/components/ui/select";
import { ResponsiveSelect } from "@/components/ui/responsive-select";
import { useToast } from "@/components/ui/use-toast";

// Manual logbook entry form. Pilots open this from the Logbook tab to record
// their own flight time; it does not auto-populate from aircraft hour logging.
export default function LogbookEntryDialog({ open, onClose, onSaved, aircraft, defaultPilotName }) {
  const { toast } = useToast();
  const [pilotName, setPilotName] = useState("");
  const [aircraftTail, setAircraftTail] = useState("");
  const [hours, setHours] = useState("");
  const [flightDate, setFlightDate] = useState(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setPilotName(defaultPilotName || "");
      setAircraftTail("");
      setHours("");
      setFlightDate(new Date().toISOString().slice(0, 10));
      setNotes("");
    }
  }, [open, defaultPilotName]);

  const save = async () => {
    const h = Number(hours);
    if (!pilotName.trim() || !h || h <= 0 || saving) return;
    setSaving(true);
    try {
      await base44.entities.PilotLog.create({
        pilot_name: pilotName.trim(),
        aircraft_tail: aircraftTail || "",
        hours: h,
        flight_date: flightDate,
        notes: notes.trim(),
      });
      toast({ title: "Logbook entry added" });
      onSaved?.();
      onClose?.();
    } catch {
      toast({ title: "Failed to add entry", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose?.()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Log flight time</DialogTitle>
          <DialogDescription>Add a manual entry to your pilot logbook.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-1">
          <div className="space-y-2">
            <Label htmlFor="lb-pilot">Pilot</Label>
            <Input id="lb-pilot" value={pilotName} onChange={(e) => setPilotName(e.target.value)} placeholder="Your name" />
          </div>
          <div className="space-y-2">
            <Label>Aircraft</Label>
            <ResponsiveSelect value={aircraftTail} onValueChange={setAircraftTail} placeholder="Select aircraft (optional)">
              {(aircraft || []).map((a) => (
                <SelectItem key={a.id} value={a.tail_number}>{a.tail_number}</SelectItem>
              ))}
            </ResponsiveSelect>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="lb-hours">Hours</Label>
              <Input id="lb-hours" type="number" step="0.1" min="0" value={hours} onChange={(e) => setHours(e.target.value)} placeholder="1.5" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lb-date">Date</Label>
              <Input id="lb-date" type="date" value={flightDate} onChange={(e) => setFlightDate(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="lb-notes">Notes</Label>
            <Input id="lb-notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={!pilotName.trim() || !Number(hours) || saving}>
            {saving ? "Saving…" : "Add entry"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}