import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { BookOpen, Clock, Plane, User, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import LogbookEntryDialog from "@/components/LogbookEntryDialog";

// Manual pilot logbook. Pilots add their own flight time here via the
// "Log Flight" button; it is no longer auto-populated from aircraft hour logging.
export default function LogbookTab({ aircraft }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [me, setMe] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.PilotLog.list("-created_date", 500);
      setLogs(list);
    } catch {
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    base44.auth.me().then(setMe).catch(() => {});
  }, []);

  const pilots = useMemo(() => {
    const map = new Map();
    for (const l of logs) {
      const name = l.pilot_name || "Unknown";
      const cur = map.get(name) || { name, totalHours: 0, flights: 0, lastDate: null };
      cur.totalHours += Number(l.hours) || 0;
      cur.flights += 1;
      if (l.flight_date && (!cur.lastDate || l.flight_date > cur.lastDate)) cur.lastDate = l.flight_date;
    }
    return Array.from(map.values()).sort((a, b) => b.totalHours - a.totalHours);
  }, [logs]);

  const totalFlights = pilots.reduce((s, p) => s + p.flights, 0);
  const fleetTotal = pilots.reduce((s, p) => s + p.totalHours, 0);
  const defaultPilotName = me?.display_name || me?.full_name || "";
  const recent = [...logs].slice(0, 8);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-muted-foreground" />
          <h3 className="font-semibold">Pilot Logbook</h3>
          <span className="text-sm text-muted-foreground">({pilots.length} pilots)</span>
        </div>
        <Button onClick={() => setAddOpen(true)}><Plus className="w-4 h-4 mr-1.5" />Log Flight</Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="rounded-xl border p-4 select-none">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Pilots</p>
          <p className="text-2xl font-semibold mt-1 flex items-center gap-1.5"><User className="w-4 h-4" />{pilots.length}</p>
        </div>
        <div className="rounded-xl border p-4 select-none">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total Flights</p>
          <p className="text-2xl font-semibold mt-1 flex items-center gap-1.5"><Plane className="w-4 h-4" />{totalFlights}</p>
        </div>
        <div className="rounded-xl border p-4 select-none col-span-2 md:col-span-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Fleet Hours</p>
          <p className="text-2xl font-semibold mt-1 flex items-center gap-1.5"><Clock className="w-4 h-4" />{fleetTotal.toFixed(1)}</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div>
      ) : pilots.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-border rounded-2xl">
          <BookOpen className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
          <p className="text-muted-foreground mb-4">No logbook entries yet. Add your flight time to start tracking.</p>
          <Button onClick={() => setAddOpen(true)}><Plus className="w-4 h-4 mr-1.5" />Log Flight</Button>
        </div>
      ) : (
        <>
          <div className="rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="text-left font-medium px-4 py-3">Pilot</th>
                    <th className="text-right font-medium px-4 py-3">Total Hours</th>
                    <th className="text-right font-medium px-4 py-3">Flights</th>
                    <th className="text-left font-medium px-4 py-3">Last Flight</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {pilots.map((p) => (
                    <tr key={p.name} className="hover:bg-muted/30">
                      <td className="px-4 py-3 font-medium">{p.name}</td>
                      <td className="px-4 py-3 text-right font-semibold">{p.totalHours.toFixed(1)}</td>
                      <td className="px-4 py-3 text-right">{p.flights}</td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{p.lastDate ? format(new Date(p.lastDate), "MMM d, yyyy") : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-2 text-muted-foreground">Recent entries</h4>
            <div className="rounded-2xl border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-xs uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="text-left font-medium px-4 py-3">Date</th>
                      <th className="text-left font-medium px-4 py-3">Pilot</th>
                      <th className="text-left font-medium px-4 py-3">Aircraft</th>
                      <th className="text-right font-medium px-4 py-3">Hours</th>
                      <th className="text-left font-medium px-4 py-3">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {recent.map((l) => (
                      <tr key={l.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 whitespace-nowrap">{l.flight_date ? format(new Date(l.flight_date), "MMM d, yyyy") : "—"}</td>
                        <td className="px-4 py-3 font-medium">{l.pilot_name || "Unknown"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{l.aircraft_tail || "—"}</td>
                        <td className="px-4 py-3 text-right font-semibold">{(Number(l.hours) || 0).toFixed(1)}</td>
                        <td className="px-4 py-3 text-muted-foreground max-w-xs truncate">{l.notes || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}

      <LogbookEntryDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSaved={load}
        aircraft={aircraft || []}
        defaultPilotName={defaultPilotName}
      />
    </div>
  );
}