import React from "react";
import { LayoutDashboard, Droplet, History, BookOpen, Plane } from "lucide-react";

const TABS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "fuel", label: "Fuel", icon: Droplet },
  { id: "audit", label: "Audit", icon: History },
  { id: "logbook", label: "Logbook", icon: BookOpen },
  { id: "mission", label: "Missions", icon: Plane },
];

// Sticky bottom tab bar for mobile viewports. Hidden on >= sm where the
// desktop header nav takes over. Uses safe-area padding to clear the iOS
// home indicator.
export default function BottomTabBar({ tab, onTab }) {
  return (
    <nav className="sm:hidden fixed bottom-0 inset-x-0 z-20 border-t border-border bg-card/95 backdrop-blur safe-px pb-safe">
      <div className="flex">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onTab(t.id)}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2 select-none ${active ? "text-primary" : "text-muted-foreground"}`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[11px] font-medium">{t.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}