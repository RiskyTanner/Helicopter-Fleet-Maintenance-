import React from "react";
import { Wrench, Plane, Clock, Calendar, Pencil, Trash2, Plus, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { hoursRemaining, daysRemainingAnnual, hoursUrgency, daysUrgency, URGENCY_STYLES, progressFraction } from "@/lib/maintenance";
import { safeHref } from "@/lib/safeUrl";

function Meter({ label, value, sub, urgency, fraction }) {
  const s = URGENCY_STYLES[urgency];
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className={`font-semibold ${s.text}`}>{value}</span>
      </div>
      <div className={`h-1.5 w-full rounded-full ${s.track}`}>
        <div className={`h-full rounded-full ${s.bg} transition-all`} style={{ width: `${Math.round(fraction * 100)}%` }} />
      </div>
      {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
    </div>);

}

export default function AircraftCard({ aircraft, isAdmin, onEdit, onDelete, onLog, onResetInspection }) {
  const a = aircraft;
  const bladeRem = hoursRemaining(a.engine_hours, a.blade_inspection_last_hours, a.blade_inspection_interval);
  const hundredRem = hoursRemaining(a.engine_hours, a.hundred_hour_last_hours, a.hundred_hour_interval);
  const annualRem = daysRemainingAnnual(a.annual_maintenance_last, a.annual_interval_months);

  const bladeU = hoursUrgency(bladeRem, a.blade_inspection_interval);
  const hundredU = hoursUrgency(hundredRem, a.hundred_hour_interval);
  const annualU = daysUrgency(annualRem);

  const inMaintenance = a.status === "maintenance";

  return (
    <div className="rounded-2xl border border-border shadow-sm overflow-hidden flex flex-col">
      <div className="p-5 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-lg font-semibold tracking-tight">{a.tail_number}</h3>
            <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${inMaintenance ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300" : "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"}`}>
              {inMaintenance ? <Wrench className="w-3 h-3" /> : <Plane className="w-3 h-3" />}
              {inMaintenance ? "Maintenance" : "Hangar"}
            </span>
          </div>
          {a.model && <p className="text-sm text-muted-foreground">{a.model}</p>}
        </div>
        <div className="flex gap-1 shrink-0">
          <Button size="icon" variant="ghost" className="h-11 w-11 sm:h-8 sm:w-8" onClick={() => onLog(a)} title="Log time"><Plus className="w-4 h-4" /></Button>
          {isAdmin && <Button size="icon" variant="ghost" className="h-11 w-11 sm:h-8 sm:w-8" onClick={() => onEdit(a)} title="Edit"><Pencil className="w-4 h-4" /></Button>}
          {isAdmin && <Button size="icon" variant="ghost" className="h-11 w-11 sm:h-8 sm:w-8 text-destructive" onClick={() => onDelete(a)} title="Delete"><Trash2 className="w-4 h-4" /></Button>}
        </div>
      </div>

      <div className="mx-5 mb-4 flex items-center gap-2">
        <div className="flex items-center gap-2 rounded-lg bg-muted/40 px-3 py-2 flex-1">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Engine Hours</p>
            <p className="text-base font-semibold">{Number(a.engine_hours || 0).toFixed(1)}</p>
          </div>
        </div>
        {a.poh_file_url &&
        <a href={safeHref(a.poh_file_url)} target="_blank" rel="noreferrer" title="View POH">
            <Button size="sm" variant="outline" type="button" className="gap-1.5">
              <FileText className="w-3.5 h-3.5" /> POH
            </Button>
          </a>
        }
      </div>

      <div className="px-5 pt-4 pb-5 space-y-3">
        <Meter
          label="Blade Inspection"
          value={bladeRem <= 0 ? "Overdue" : `${bladeRem.toFixed(1)} hrs left`}
          sub={`every ${a.blade_inspection_interval} hrs`}
          urgency={bladeU}
          fraction={progressFraction(bladeRem, a.blade_inspection_interval)} />
        
        <Meter
          label="100-Hour Inspection"
          value={hundredRem <= 0 ? "Overdue" : `${hundredRem.toFixed(1)} hrs left`}
          sub={`every ${a.hundred_hour_interval} hrs`}
          urgency={hundredU}
          fraction={progressFraction(hundredRem, a.hundred_hour_interval)} />
        
        <Meter
          label="Annual Maintenance"
          value={annualRem === null ? "Not set" : annualRem <= 0 ? "Overdue" : `${annualRem} days left`}
          sub={`every ${a.annual_interval_months} months`}
          urgency={annualU}
          fraction={annualRem === null ? 0 : Math.max(0, Math.min(1, 1 - annualRem / ((Number(a.annual_interval_months) || 12) * 30)))} />
        
      </div>

      {isAdmin && (bladeU === "red" || hundredU === "red" || annualU === "red") &&
      <div className="px-5 pb-5">
          <Button size="sm" variant="outline" className="w-full" onClick={() => onResetInspection(a)}>
            <Calendar className="w-3.5 h-3.5 mr-1.5" /> Mark overdue inspection done
          </Button>
        </div>
      }

      {a.notes && <p className="px-5 pb-5 text-xs text-muted-foreground italic">"{a.notes}"</p>}
    </div>);

}