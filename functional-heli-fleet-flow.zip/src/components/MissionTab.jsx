import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { Plane, Clock, Flag, Inbox } from "lucide-react";
import { missionLabel } from "@/lib/missionTypes";

const TYPE_BADGE = {
  training: "bg-blue-100 text-blue-800 dark:bg-blue-950/50 dark:text-blue-300",
  patrol: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300",
  touch_a_truck: "bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300",
  ems: "bg-red-100 text-red-800 dark:bg-red-950/50 dark:text-red-300",
  sar: "bg-purple-100 text-purple-800 dark:bg-purple-950/50 dark:text-purple-300",
  transport: "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/50 dark:text-cyan-300",
  maint_flight: "bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-200",
  other: "bg-muted text-muted-foreground",
};

const badge = (t) => TYPE_BADGE[t] || "bg-muted text-muted-foreground";

// Auto-fills from logged flight time: every FlightLog "flight" entry with a
// mission type appears here, grouped by airframe.
export default function MissionTab() {
  const [missions, setMissions] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.FlightLog.filter({ entry_type: "flight" }, "-created_date", 200);
      setMissions(list || []);
    } catch {
      setMissions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const entries = missions || [];
  const totalHours = entries.reduce((s, m) => s + (Number(m.hours_added) || 0), 0);

  const groups = {};
  entries.forEach((m) => {
    const tail = m.aircraft_tail || "Unknown";
    (groups[tail] = groups[tail] || []).push(m);
  });
  const groupKeys = Object.keys(groups).sort((a, b) => {
    const ha = groups[a].reduce((s, m) => s + (Number(m.hours_added) || 0), 0);
    const hb = groups[b].reduce((s, m) => s + (Number(m.hours_added) || 0), 0);
    return hb - ha;
  });

  return (
    <div>
      <div className="flex items-center gap-2 mb-1">
        <Plane className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-semibold">Missions</h2>
      </div>
      <p className="text-sm text-muted-foreground mb-6">
        Auto-filled from logged flight time on each airframe.
      </p>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <Stat icon={<Flag className="w-4 h-4" />} label="Missions" value={entries.length} />
        <Stat icon={<Clock className="w-4 h-4" />} label="Flight Hours" value={totalHours.toFixed(1)} />
        <Stat icon={<Plane className="w-4 h-4" />} label="Airframes" value={groupKeys.length} />
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin dark:border-slate-700 dark:border-t-slate-200" />
        </div>
      ) : entries.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-border rounded-2xl">
          <Inbox className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
          <p className="text-muted-foreground max-w-md mx-auto">
            No missions yet. Log flight hours on an airframe and select a mission type to auto-fill this tab.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {groupKeys.map((tail) => {
            const items = groups[tail];
            const hrs = items.reduce((s, m) => s + (Number(m.hours_added) || 0), 0);
            return (
              <div key={tail} className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Plane className="w-4 h-4 text-muted-foreground" />
                    <span className="font-semibold">{tail}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {items.length} {items.length === 1 ? "mission" : "missions"} ·{" "}
                    <span className="font-semibold text-foreground">{hrs.toFixed(1)}h</span>
                  </div>
                </div>
                <div className="divide-y divide-border">
                  {items.map((m) => (
                    <div key={m.id} className="flex items-start justify-between gap-3 px-4 py-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${badge(m.mission_type)}`}>
                            {missionLabel(m.mission_type)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {m.created_date ? format(new Date(m.created_date), "MMM d, yyyy · HH:mm") : ""}
                          </span>
                        </div>
                        <p className="text-sm mt-1 text-muted-foreground truncate">
                          {m.pilot_name || "Unknown"}
                          {m.notes && m.notes !== "Flight time logged" ? ` · ${m.notes}` : ""}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-semibold">{Number(m.hours_added || 0).toFixed(1)}h</p>
                        {Number(m.fuel_change || 0) !== 0 && (
                          <p className="text-xs text-muted-foreground">{Number(m.fuel_change).toFixed(1)} gal</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ icon, label, value }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground uppercase tracking-wide">
        {icon}
        {label}
      </div>
      <p className="text-2xl font-semibold mt-1">{value}</p>
    </div>
  );
}