import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Plus, AlertTriangle, Droplet, History, LayoutDashboard, Settings, BookOpen, Plane } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import { Image } from "@/components/ui/image";
import AircraftCard from "@/components/AircraftCard";
import AircraftForm from "@/components/AircraftForm";
import LogHoursDialog from "@/components/LogHoursDialog";
import FuelTab from "@/components/FuelTab";
import AuditLogTab from "@/components/AuditLogTab";
import LogbookTab from "@/components/LogbookTab";
import MissionTab from "@/components/MissionTab";
import ThemeToggle from "@/components/ThemeToggle";
import BottomTabBar from "@/components/BottomTabBar";
import PullToRefresh from "@/components/PullToRefresh";
import WeatherWidget from "@/components/WeatherWidget";
import SettingsDialog from "@/components/SettingsDialog";
import DisplayNameDialog from "@/components/DisplayNameDialog";
import { hoursRemaining, daysRemainingAnnual, hoursUrgency, daysUrgency } from "@/lib/maintenance";
import { recordLogEntry } from "@/lib/logEntry";
import { useToast } from "@/components/ui/use-toast";

const EMBLEM_URL = "https://media.base44.com/images/public/6aaec9d4bc7e639637752fcf/902f85e7b_Helicopter.jpg";

const TABS = [
{ id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
{ id: "fuel", label: "Fuel On Site", icon: Droplet },
{ id: "audit", label: "Audit Log", icon: History },
{ id: "logbook", label: "Logbook", icon: BookOpen },
{ id: "mission", label: "Missions", icon: Plane }];


async function getOrCreateSiteFuel() {
  const list = await base44.entities.SiteFuel.list("-updated_date", 1);
  if (list.length) return list[0];
  return await base44.entities.SiteFuel.create({ total_fuel_on_site: 0 });
}

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get("tab") || "dashboard";
  // Modal/panel state lives in the URL so the iOS back button / swipe gesture
  // closes open sheets instead of exiting the app.
  const updateParams = (updates, { replace = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => {
      if (v === null || v === undefined || v === false) next.delete(k);
      else next.set(k, String(v));
    });
    setSearchParams(next, { replace });
  };
  // Tab switches replace history so back isn't cluttered with each tab;
  // modals still push so swipe/back can dismiss them.
  const setTab = (t) => updateParams({ tab: t }, { replace: true });
  const addOpen = searchParams.get("add") === "true";
  const editId = searchParams.get("edit");
  const logId = searchParams.get("log");
  const settingsOpen = searchParams.get("settings") === "true";

  const aircraftQuery = useQuery({
    queryKey: ["aircraft"],
    queryFn: () => base44.entities.Aircraft.list("-updated_date", 100),
  });
  const fuelQuery = useQuery({ queryKey: ["siteFuel"], queryFn: getOrCreateSiteFuel });
  const userQuery = useQuery({ queryKey: ["me"], queryFn: () => base44.auth.me(), retry: false });

  const aircraft = aircraftQuery.data ?? [];
  const siteFuel = fuelQuery.data ?? null;
  const user = userQuery.data ?? null;
  const isAdmin = user?.role === "admin";
  const needsName = !!user && !user.display_name && !user.full_name;
  const editing = editId ? aircraft.find((a) => a.id === editId) || null : null;
  const logTarget = logId ? aircraft.find((a) => a.id === logId) || null : null;
  const formOpen = addOpen || !!editing;
  const loading = aircraftQuery.isLoading || fuelQuery.isLoading;

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["aircraft"] }),
      queryClient.invalidateQueries({ queryKey: ["siteFuel"] }),
    ]);
  };

  const createAircraftMutation = useMutation({
    mutationFn: async (payload) => {
      const created = await base44.entities.Aircraft.create(payload);
      await recordLogEntry({ aircraft: created, entryType: "create", notes: "Aircraft added to fleet" });
      return created;
    },
    onSuccess: () => { toast({ title: "Aircraft added" }); queryClient.invalidateQueries({ queryKey: ["aircraft"] }); },
    onError: () => toast({ title: "Failed to add aircraft", variant: "destructive" }),
  });

  const updateAircraftMutation = useMutation({
    mutationFn: async ({ id, payload }) => {
      const { created_date, updated_date, created_by_id, ...rest } = payload;
      await base44.entities.Aircraft.update(id, rest);
      await recordLogEntry({ aircraft: { id, tail_number: payload.tail_number }, entryType: "edit", notes: "Aircraft record edited" });
      return { id, rest };
    },
    onMutate: async ({ id, payload }) => {
      const { created_date, updated_date, created_by_id, ...rest } = payload;
      await queryClient.cancelQueries({ queryKey: ["aircraft"] });
      const previous = queryClient.getQueryData(["aircraft"]);
      queryClient.setQueryData(["aircraft"], (old) => (old ?? []).map((a) => (a.id === id ? { ...a, ...rest } : a)));
      return { previous };
    },
    onError: (_e, _v, context) => {
      if (context?.previous) queryClient.setQueryData(["aircraft"], context.previous);
      toast({ title: "Failed to update aircraft", variant: "destructive" });
    },
    onSuccess: () => toast({ title: "Aircraft updated" }),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["aircraft"] }),
  });

  const logHoursMutation = useMutation({
    mutationFn: async ({ target, hoursAdded, fuelChange, missionType }) => {
      const newHours = (Number(target.engine_hours) || 0) + hoursAdded;
      await base44.entities.Aircraft.update(target.id, { engine_hours: newHours });
      if (fuelChange) {
        const cur = queryClient.getQueryData(["siteFuel"]);
        if (cur) {
          const newFuelTotal = Math.max(0, (Number(cur.total_fuel_on_site) || 0) + fuelChange);
          await base44.entities.SiteFuel.update(cur.id, { total_fuel_on_site: newFuelTotal });
        }
      }
      await recordLogEntry({ aircraft: target, hoursAdded, fuelChange, entryType: "flight", missionType, notes: "Flight time logged" });
    },
    onMutate: async ({ target, hoursAdded, fuelChange }) => {
      await queryClient.cancelQueries({ queryKey: ["aircraft"] });
      await queryClient.cancelQueries({ queryKey: ["siteFuel"] });
      const prevAircraft = queryClient.getQueryData(["aircraft"]);
      const prevFuel = queryClient.getQueryData(["siteFuel"]);
      const newHours = (Number(target.engine_hours) || 0) + hoursAdded;
      queryClient.setQueryData(["aircraft"], (old) => (old ?? []).map((a) => (a.id === target.id ? { ...a, engine_hours: newHours } : a)));
      if (fuelChange && prevFuel) {
        const newTotal = Math.max(0, (Number(prevFuel.total_fuel_on_site) || 0) + fuelChange);
        queryClient.setQueryData(["siteFuel"], { ...prevFuel, total_fuel_on_site: newTotal });
      }
      return { prevAircraft, prevFuel };
    },
    onError: (_e, _v, context) => {
      if (context?.prevAircraft) queryClient.setQueryData(["aircraft"], context.prevAircraft);
      if (context?.prevFuel) queryClient.setQueryData(["siteFuel"], context.prevFuel);
      toast({ title: "Failed to log time", variant: "destructive" });
    },
    onSuccess: () => toast({ title: "Time logged" }),
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["aircraft"] });
      queryClient.invalidateQueries({ queryKey: ["siteFuel"] });
    },
  });

  const deleteAircraftMutation = useMutation({
    mutationFn: async (a) => { await base44.entities.Aircraft.delete(a.id); },
    onSuccess: () => { toast({ title: "Aircraft deleted" }); queryClient.invalidateQueries({ queryKey: ["aircraft"] }); },
    onError: () => toast({ title: "Failed to delete aircraft", variant: "destructive" }),
  });

  const resetInspectionMutation = useMutation({
    mutationFn: async ({ a, updates, done }) => {
      await base44.entities.Aircraft.update(a.id, updates);
      await recordLogEntry({ aircraft: a, entryType: "inspection", notes: `Inspection completed: ${done.join(", ")}` });
    },
    onSuccess: () => { toast({ title: "Inspection recorded" }); queryClient.invalidateQueries({ queryKey: ["aircraft"] }); },
    onError: () => toast({ title: "Failed to record inspection", variant: "destructive" }),
  });

  const saveAircraft = async (data) => {
    if (editing?.id) {
      await updateAircraftMutation.mutateAsync({ id: editing.id, payload: data });
    } else {
      await createAircraftMutation.mutateAsync(data);
    }
  };

  const applyLog = async ({ hoursAdded, fuelChange, missionType }) => {
    await logHoursMutation.mutateAsync({ target: logTarget, hoursAdded, fuelChange, missionType });
  };

  const removeAircraft = (a) => {
    if (!confirm(`Delete ${a.tail_number}?`)) return;
    deleteAircraftMutation.mutate(a);
  };

  const resetInspection = (a) => {
    const bladeRem = hoursRemaining(a.engine_hours, a.blade_inspection_last_hours, a.blade_inspection_interval);
    const hundredRem = hoursRemaining(a.engine_hours, a.hundred_hour_last_hours, a.hundred_hour_interval);
    const annualRem = daysRemainingAnnual(a.annual_maintenance_last, a.annual_interval_months);
    const updates = {};
    const done = [];
    if (hoursUrgency(bladeRem, a.blade_inspection_interval) === "red") { updates.blade_inspection_last_hours = Number(a.engine_hours) || 0; done.push("blade"); }
    if (hoursUrgency(hundredRem, a.hundred_hour_interval) === "red") { updates.hundred_hour_last_hours = Number(a.engine_hours) || 0; done.push("100-hour"); }
    if (daysUrgency(annualRem) === "red") {
      const d = new Date(); updates.annual_maintenance_last = d.toISOString().slice(0, 10); done.push("annual");
    }
    if (Object.keys(updates).length) {
      resetInspectionMutation.mutate({ a, updates, done });
    }
  };

  const openAdd = () => updateParams({ add: "true", edit: null });
  const openEdit = (a) => updateParams({ edit: a.id, add: null });
  const openLog = (a) => updateParams({ log: a.id });

  const overdueCount = aircraft.filter((a) => {
    const b = hoursUrgency(hoursRemaining(a.engine_hours, a.blade_inspection_last_hours, a.blade_inspection_interval), a.blade_inspection_interval);
    const h = hoursUrgency(hoursRemaining(a.engine_hours, a.hundred_hour_last_hours, a.hundred_hour_interval), a.hundred_hour_interval);
    const an = daysUrgency(daysRemainingAnnual(a.annual_maintenance_last, a.annual_interval_months));
    return b === "red" || h === "red" || an === "red";
  }).length;

  const inMaintenance = aircraft.filter((a) => a.status === "maintenance").length;
  const totalFuel = Number(siteFuel?.total_fuel_on_site || 0);

  return (
    <div className="min-h-screen">
      <header className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10 safe-top">
        <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-11 w-20 shrink-0 rounded-md overflow-hidden">
              <Image src={EMBLEM_URL} alt="Williamson Sheriff's Aviation Unit emblem" className="h-full w-full" fittingType="fit" />
            </div>
            <div className="min-w-0">
              <h1 className="text-lg md:text-xl tracking-tight truncate text-[hsl(var(--foreground))] [font-family:'Albert_Sans',_sans-serif] font-bold">Williamson Sheriff's Aviation Unit</h1>
              <p className="text-xs text-muted-foreground">Helicopter Maintenance Tracker</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => updateParams({ settings: "true" })} title="Settings"><Settings className="w-4 h-4" /></Button>
            <ThemeToggle />
            {isAdmin && <Button onClick={openAdd} className="hidden sm:inline-flex"><Plus className="w-4 h-4 mr-1.5" />Add Aircraft</Button>}
            {isAdmin && <Button onClick={openAdd} size="icon" className="sm:hidden"><Plus className="w-4 h-4" /></Button>}
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-6">
          <nav className="hidden sm:flex gap-1 -mb-px">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>

                  <Icon className="w-4 h-4" />{t.label}
                </button>);

            })}
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8 pb-24 sm:pb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
          >
            {tab === "dashboard" &&
            <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  <Stat label="Aircraft" value={aircraft.length} />
                  <Stat label="In Maintenance" value={inMaintenance} tone={inMaintenance ? "amber" : "default"} />
                  <Stat label="Fuel On Site" value={`${totalFuel.toFixed(1)} gal`} />
                  <Stat label="Inspections Due" value={overdueCount} tone={overdueCount ? "red" : "default"} icon={overdueCount ? <AlertTriangle className="w-4 h-4" /> : null} />
                </div>

                <PullToRefresh onRefresh={refresh}>
                {loading ?
                <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div> :
                aircraft.length === 0 ?
                <div className="text-center py-20 border-2 border-dashed border-border rounded-2xl">
                    <p className="text-muted-foreground mb-4">No aircraft yet. {isAdmin ? "Add your first helicopter to start tracking." : "Ask an admin to add the first helicopter."}</p>
                    {isAdmin && <Button onClick={openAdd}><Plus className="w-4 h-4 mr-1.5" />Add Aircraft</Button>}
                  </div> :

                <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_300px] lg:gap-6">
                  <div className="min-w-0 order-2 lg:order-1">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
                    {aircraft.map((a) =>
                  <AircraftCard key={a.id} aircraft={a} isAdmin={isAdmin} onEdit={openEdit} onDelete={removeAircraft}                       onLog={openLog} onResetInspection={resetInspection} />
                  )}
                    </div>
                  </div>
                  <aside className="order-1 lg:order-2 lg:sticky lg:top-24 lg:self-start mb-5 lg:mb-0">
                    <WeatherWidget />
                  </aside>
                </div>
                }
                </PullToRefresh>
              </>
            }

            {tab === "fuel" && (
            loading || !siteFuel ? <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div> :
            <FuelTab siteFuel={siteFuel} onReload={refresh} />)
            }

            {tab === "audit" && <AuditLogTab aircraft={aircraft} />}

            {tab === "logbook" && <LogbookTab aircraft={aircraft} />}

            {tab === "mission" && <MissionTab />}
          </motion.div>
        </AnimatePresence>
      </main>

      <AircraftForm open={formOpen} onClose={() => updateParams({ add: null, edit: null })} onSave={saveAircraft} aircraft={editing} />
      <LogHoursDialog open={!!logTarget} onClose={() => updateParams({ log: null })} onApply={applyLog} aircraft={logTarget} siteFuel={siteFuel} />
      <BottomTabBar tab={tab} onTab={setTab} />
      <SettingsDialog open={settingsOpen} onClose={() => updateParams({ settings: null })} />
      <DisplayNameDialog open={needsName} user={user} onSaved={() => queryClient.invalidateQueries({ queryKey: ["me"] })} />
    </div>);

}

function Stat({ label, value, tone = "default", icon }) {
  const tones = { default: "bg-card", amber: "bg-amber-50 border-amber-200 dark:bg-amber-950/40 dark:border-amber-900", red: "bg-red-50 border-red-200 dark:bg-red-950/40 dark:border-red-900" };
  const textTones = { default: "", amber: "text-amber-800 dark:text-amber-400", red: "text-red-800 dark:text-red-400" };
  return (
    <div className={`rounded-xl border p-4 select-none ${tones[tone]}`}>
      <p className="text-xs text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className={`text-2xl font-semibold mt-1 flex items-center gap-1.5 ${textTones[tone]}`}>{icon}{value}</p>
    </div>);

}