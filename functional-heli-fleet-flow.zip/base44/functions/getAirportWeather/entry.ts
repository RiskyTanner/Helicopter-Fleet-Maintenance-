import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Returns the latest weather observation for Nashville International (KBNA)
// from the NWS public API. No API key required.
const STATION = 'KBNA';
const STATION_NAME = 'Nashville Intl';

function degToCardinal(deg) {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}

function round(n, d = 1) {
  if (n == null || Number.isNaN(n)) return null;
  const f = Math.pow(10, d);
  return Math.round(n * f) / f;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const res = await fetch(`https://api.weather.gov/stations/${STATION}/observations/latest`, {
      headers: { 'Accept': 'application/geo+json', 'User-Agent': 'HeliTrack-Pro' }
    });
    if (!res.ok) return Response.json({ error: 'Weather source unavailable' }, { status: 502 });
    const data = await res.json();
    const p = data.properties || {};

    const tempC = p.temperature?.value ?? null;
    const pressurePa = p.barometricPressure?.value ?? null;
    const windKmh = p.windSpeed?.value ?? null;
    const windDir = p.windDirection?.value ?? null;

    // Density altitude (feet) from station pressure and temperature.
    let densityAltitudeFt = null;
    if (pressurePa != null && tempC != null) {
      const pIn = pressurePa / 3386.39;
      const tRankine = tempC * 9 / 5 + 491.67;
      densityAltitudeFt = Math.round(145366 * (1 - Math.pow((17.326 * pIn) / tRankine, 0.235)));
    }

    // METAR-style wind string, e.g. "34010kt" (3-digit direction + 2-digit speed + kt).
    let windMetar = null;
    if (windKmh != null) {
      const speedKt = Math.round(windKmh / 1.852);
      const dir = windDir != null ? String(Math.round(windDir)).padStart(3, '0') : 'VRB';
      windMetar = `${dir}${String(speedKt).padStart(2, '0')}kt`;
    }

    return Response.json({
      station: STATION,
      station_name: STATION_NAME,
      summary: p.textDescription || '',
      temperature_f: tempC != null ? round(tempC * 9 / 5 + 32) : null,
      temperature_c: tempC != null ? round(tempC) : null,
      pressure_inhg: pressurePa != null ? round(pressurePa / 3386.39, 2) : null,
      pressure_mb: pressurePa != null ? round(pressurePa / 100, 1) : null,
      density_altitude_ft: densityAltitudeFt,
      wind_metar: windMetar,
      wind_mph: windKmh != null ? round(windKmh / 1.60934) : null,
      wind_kt: windKmh != null ? round(windKmh / 1.852) : null,
      wind_direction_deg: windDir != null ? round(windDir, 0) : null,
      wind_direction_cardinal: windDir != null ? degToCardinal(windDir) : null,
      observation_time: p.timestamp || null
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}